library(tidyverse)
library(purrr)
library(psych)
Sys.setlocale("LC_TIME", "English")
#--------------------------------------------------------------------------
#     3.3 data pre-processing
#--------------------------------------------------------------------------

# Since R project files are used directly, there is no need to specify a work path
# setwd("C:/Users/tclkr/Desktop/COVID19")

data_state_local<-read.csv("../data/reference.csv")
data_state_number<-read.csv("../data/time-series-19-covid-combined.csv")
data_us_confirmed<-read.csv("../data/us_confirmed.csv")
data_us_die<-read.csv("../data/us_deaths.csv")
data_world_summary<-read.csv("../data/worldwide-aggregated.csv")

get_key<-function(a,b){
  if(a==''){
    # ..I ran into a weird bug here that only works this way
    return(paste(b))
  }
  return(paste(a,sep =" ,",b))
}

## clean the data
### data of global states&country
data_state_local$Combined_Key=as.character(data_state_local$Combined_Key)
data_glb<-data_state_number%>%
  # the location data here not precise
  select(-Long,-Lat)%>%
  mutate(Combined_Key = purrr::map2_chr(Province.State,Country.Region,get_key))

# Clean the main key
data_state_local$Combined_Key<-gsub(" , ",",",data_state_local$Combined_Key)
data_state_local$Combined_Key<-gsub(", ",",",data_state_local$Combined_Key)
data_state_local$Combined_Key<-gsub(" ,",",",data_state_local$Combined_Key)
data_glb$Combined_Key<-gsub(" , ",",",data_glb$Combined_Key)
data_glb$Combined_Key<-gsub(", ",",",data_glb$Combined_Key)
data_glb$Combined_Key<-gsub(" ,",",",data_glb$Combined_Key)

data_glb<-data_glb%>%
  left_join(select(data_state_local,-c(UID:Country_Region)),by="Combined_Key")

# If merge by follow way will only have 68% local data
data_state_local$Country_Region<-as.character(data_state_local$Country_Region)
data_state_number$Country.Region<-as.character(data_state_number$Country.Region)
data_state_local$Province_State<-as.character(data_state_local$Province_State)
data_state_number$Province.State<-as.character(data_state_number$Province.State)
data_glb<-data_state_number%>%
  # ..the location data here not precise
  select(-Long,-Lat)%>%
  left_join(select(data_state_local,-c(UID:Country_Region)),by=c("Country.Region","Provience.State"))

### data of us
data_us_confirmed$Combined_Key=as.character(data_us_confirmed$Combined_Key)
data_us_confirmed<-data_us_confirmed%>%
  select(Combined_Key,Date,Case)
data_us_die$Combined_Key=as.character(data_us_die$Combined_Key)
data_us_die<-data_us_die%>%
  select(-c(UID:Admin2))
data_us<-data_us_confirmed%>%
  left_join(data_us_die,by=c("Combined_Key","Date"))%>%
  mutate(confirmed=Case.x,die=Case.y)%>%
  select(-Case.x,-Case.y,-Country.Region)

### remove useless data
rm(data_state_local,data_state_number,data_us_confirmed,data_us_die)

### change format
data_us<-as_tibble(data_us)
data_glb<-as_tibble(data_glb)%>%
  filter(is.na(Recovered)==FALSE,is.na(Confirmed)==FALSE,is.na(Deaths)==FALSE,
         is.na(Long_)==FALSE,is.na(Lat)==FALSE,is.na(Population)==FALSE)
data_world_summary<-as_tibble(data_world_summary)
data_world_summary$Date<-as.Date(data_world_summary$Date)
data_us$Date<-as.Date(data_us$Date)
data_glb$Date<-as.Date(data_glb$Date)

# Preview time-population relations
ggplot()+
  geom_point(data=data_world_summary,mapping=aes(x=Date,y=Confirmed-Recovered))+
  theme(axis.text.x = element_text(angle = 45, hjust = 1.3))+
  scale_x_date(date_breaks = "1 week", date_minor_breaks = "1 week", date_labels = "%b%d")+
  labs(x="Date",y="Population")

## Calculate data integrity
# If want to see, don't run lines 72 to 74 (clean code)
for(i in seq_along(data_glb)){
  print(100-100*sum(as.vector(is.na(data_glb[,i])))/as.integer(count(data_glb[,i])))
}
# Free the temporary variable
rm(i)

## Calculated correlation coefficient
get_per_cor<-function(x,y){
  x<-as.integer(x)
  y<-as.integer(y)
  n<-length(y)
  mean_x<-mean(x)
  mean_y<-mean(y)
  sd_x<-sd(x)
  sd_y<-sd(y)
  print(sd_x)
  cov_xy<-sum((x-mean_x)*(y-mean_y))/(n-1)
  return(cov_xy/sd_x/sd_y)
}

# Not support 'for' can only write by line
get_per_cor(as.integer(data_world_summary$Date-as.Date("2020-01-21")),as.integer(data_world_summary$Date-as.Date("2020-01-21")))
get_per_cor(as.integer(data_world_summary$Date-as.Date("2020-01-21")),data_world_summary$Recovered)
get_per_cor(as.integer(data_world_summary$Date-as.Date("2020-01-21")),data_world_summary$Confirmed)
get_per_cor(as.integer(data_world_summary$Date-as.Date("2020-01-21")),data_world_summary$Deaths)

get_per_cor(data_world_summary$Recovered,as.integer(data_world_summary$Date-as.Date("2020-01-21")))
get_per_cor(data_world_summary$Recovered,data_world_summary$Recovered)
get_per_cor(data_world_summary$Recovered,data_world_summary$Confirmed)
get_per_cor(data_world_summary$Recovered,data_world_summary$Deaths)

get_per_cor(data_world_summary$Confirmed,as.integer(data_world_summary$Date-as.Date("2020-01-21")))
get_per_cor(data_world_summary$Confirmed,data_world_summary$Recovered)
get_per_cor(data_world_summary$Confirmed,data_world_summary$Confirmed)
get_per_cor(data_world_summary$Confirmed,data_world_summary$Deaths)

get_per_cor(data_world_summary$Deaths,as.integer(data_world_summary$Date-as.Date("2020-01-21")))
get_per_cor(data_world_summary$Deaths,data_world_summary$Recovered)
get_per_cor(data_world_summary$Deaths,data_world_summary$Confirmed)
get_per_cor(data_world_summary$Deaths,data_world_summary$Deaths)

data_world_summary2<-data_world_summary[-1,]
get_per_cor(data_world_summary2$Increase.rate,as.integer(data_world_summary2$Date-as.Date("2020-01-21")))
get_per_cor(data_world_summary2$Increase.rate,data_world_summary2$Recovered)
get_per_cor(data_world_summary2$Increase.rate,data_world_summary2$Confirmed)
get_per_cor(data_world_summary2$Increase.rate,data_world_summary2$Deaths)
get_per_cor(data_world_summary2$Increase.rate,data_world_summary2$Increase.rate)
get_per_cor(data_world_summary2$Deaths,data_world_summary2$Increase.rate)
get_per_cor(data_world_summary2$Recovered,data_world_summary2$Increase.rate)
get_per_cor(data_world_summary2$Confirmed,data_world_summary2$Increase.rate)
get_per_cor(as.integer(data_world_summary2$Date-as.Date("2020-01-21")),data_world_summary2[,-1]$Increase.rate)
rm(data_world_summary2)

# Can't convert directly, can only copy by line
cor_res<-tribble(
  ~Var1,              ~Var2,           ~Value,
  "Date",             "Date",          1,
  "Date",             "Confirmed",     0.8065011,
  "Date",             "Recovered",     0.8404169,
  "Date",             "Deaths",        0.7655985,
  "Date",             "Increase rate", -0.4506009,
  "Confirmed",        "Date",          0.8065011,
  "Confirmed",        "Confirmed",     1,
  "Confirmed",        "Recovered",     0.9893401,
  "Confirmed",        "Deaths",        0.9953976,
  "Confirmed",        "Increase rate", -0.2113539,
  "Recovered",        "Date",          0.8404169,
  "Recovered",        "Confirmed",     0.8065011,
  "Recovered",        "Recovered",     1,
  "Recovered",        "Deaths",        0.9887518,
  "Recovered",        "Increase rate", -0.2457062,
  "Deaths",           "Date",          0.7655985,
  "Deaths",           "Confirmed",     0.9953976,
  "Deaths",           "Recovered",     0.9887518,
  "Deaths",           "Deaths",        1,
  "Deaths",           "Increase rate", -0.1953711,
  "Increase rate",    "Date",          -0.4506009,
  "Increase rate",    "Confirmed",     -0.2113539,
  "Increase rate",    "Recovered",     -0.2457062,
  "Increase rate",    "Deaths",        -0.1953711,
  "Increase rate",    "Increase rate", 1
)

# Correlation coefficient heat map
ggplot(data = cor_res, aes(x=Var2, y=Var1, fill = Value)) +
  geom_tile(color = "white") +
  scale_fill_gradient2(low = "blue", high = "red", mid = "white",
                       midpoint = 0, limit = c(-1, 1), space = "Lab",
                       name="Pearson coefficient") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                   size = 12, hjust = 1)) +
  coord_fixed() + 
  geom_text(aes(Var2, Var1, label = Value), color = "black", size = 3)+
  labs(x="Var1",y="Var2")
# Free the temporary variable
rm(cor_res)

## Data normalization processing
normalizate<-function(data){
  dmax<-max(data)
  dmin<-min(data)
  return((data-dmin)/(dmax-dmin))
}

# Uniformization
data_glb$Confirmed<-normalizate(data_glb$Confirmed)
data_glb$Recovered<-normalizate(data_glb$Recovered)
data_glb$Deaths<-normalizate(data_glb$Deaths)

data_us$confirmed<-normalizate(data_us$confirmed)
data_us$die<-normalizate(data_us$die)

data_world_summary$Confirmed<-normalizate(data_world_summary$Confirmed)
data_world_summary$Recovered<-normalizate(data_world_summary$Recovered)
data_world_summary$Deaths<-normalizate(data_world_summary$Deaths)

# R-cluster
## add new datas
data_R_cluste<-tribble(
    ~Disease_Name,    ~Confirmed,    ~Deaths,     ~Recovered,       ~Death_Rate,   ~R0_min,	      ~R0_max,    ~incubation,    ~Rate_asymptomatic,     ~Date,      ~Country_Rate,    ~Origin_City_Population,    ~GDP,    ~Density_People,     ~Act_Gov,
    "Hepatitis B",  	300000000,    	17000,    	2999998300,	      0.000005,      1,            	2,        	70,           	0,                    	8030,      	1,              	15305900,                 	21874,  	2059,             	NA,
    "Black Death",  	85000000,     	78700000,  	6300000,        	0.9258,        1,	            3,	        3, 	            0.12,                  	2555,     	1,              	70000000,                 	31058,   	16,               	0,
    "cholera",     	  461783,       	8072,      	453711,          	0.0068,        1,           	2,        	2,            	0.07,                  	1277,      	1,              	7510100,                  	3894,     554,              	NA,
    "measles",      	250270,       	5110,     	245160,          	0.0020,        12,          	18,       	10,           	0.08,                 	317,      	0.025,          	1800000,                  	3198,     1772,              	NA,
    "diphtheria",   	2839,          	67,        	2772,           	0.0235,        6,	            7,	        3,	            0.11,	                  115,	      0.01,	            257740000,                  3894,   	554,               	NA,
    "smallpox",     	6000,          	850,        5150,            	0.3,           5,           	7,	        14,	            0,	                    730,	      1,	              11000,                    	46170,   	963,               	NA,
    "polio",      	  NA,            	NA,	        NA,              	NA,            5,	            7,	        11,	            0,	                    NA,	        1,	              NA,	                        NA,     	NA,               	NA, 
    "rubella",    	  NA,           	NA,	        NA,             	0.0013,        5,	            7,	        11,	            0.01,                   NA,	        NA,	              NA,	                        NA,     	NA,               	NA,
    "Mumps",      	  NA,            	NA,	        NA,             	0.0002,     	 5,           	7,	        19,	            0.06,                   NA,	        NA,	              NA,	                        NA,     	NA,               	NA, 
    "HIV/AIDS",   	  NA,           	NA,	        NA,             	NA,         	 2,	            5,	        11,	            0.04,                   NA,	        1,	              NA,	                        NA,     	NA,               	NA,
    "pertussis",  	  75598200,     	5292,      	75592908,       	0.00007,     	 4,   	        7,	        13,	            0.09,                   183,        1,	              8900000,                    46500,  	4761,             	NA,
    "SARS",       	  8422,          	919,       	7503,           	0.17,          0.85,        	3,	        7,	            0.11,                   270,        0.162,	          7251900,	                  7404,     975,              	NA,
    "MERS",       	  1139,         	431,       	708,            	0.37,       	 1,	            2,	        5.2,	          0.18,                   218,        0.061,	          436000,                     25059,		965,                NA,
    "HIN1",       	  25449514,     	19449,     	25430065,       	0.012,       	 1.75,	        1.75,	      4,	            0.19,                   485,        1,	              38310000,                 	49911,   	90,                	NA,
    "COVID-19",   	  7221717,      	411818,	    6809899,         	0.05,        	 3.77,	        3.77,	      14, 	          0.17,                   190,        1,	              12212000,                  	21098,   	2334,              	1
)

# Coefficient of correlation
data_R_cluste<-data_R_cluste%>%
  filter(is.na(Confirmed)==FALSE)%>%
  select(-Act_Gov)
x_star<-scale(as.data.frame(select(data_R_cluste,-Disease_Name)))
hc<-hclust(dist(x_star),method = "ave")
plot(hc,hang=-1)
# Find the normalized correlation coefficient
sc<-as.data.frame(select(data_R_cluste,-Disease_Name))
center <- sweep(sc, 2, apply(sc, 2, min),'-')  
R <- apply(sc, 2, max) - apply(sc,2,min)       
x_star<- sweep(center, 2, R, "/")             
hc<-hclust(dist(x_star),method = "ave")
plot(hc,hang=-1)
# Free the temporary variable
rm(hc,sc,x_star,center)

# Q-cluster
data_R_cluste<-select(data_R_cluste,-Disease_Name)
sc<-t(sc)
x_star<-t(x_star)
sc<-dist(data_R_cluste,"minkowski")
hc<-hclust(dist(sc),method = "ave")
plot(hc,hang=-1)

# PCA
d<-data_R_cluste
sd=scale(d)
sd
pca=princomp(d,cor=T) 
screeplot(pca,type="line",lwd=2) 
dcor=cor(d)
deig=eigen(dcor)
deig$values
sumeigv=sum(deig$values)
sumeigv
sum(deig$values[1:2])/k
pca$loadings[,1:2]
deigvalues[1]/k
deigvalues[2]/k
C=(b1*C1+b2*C2)/(b1+b2)=q1*C1+q2*C2
s=pca$scores[,1:2] 
cbind(s,c)

# can't converse the data, just copy four parameters
res<-scale(as.data.frame(select(data_R_cluste,-Disease_Name)))%>%
  as_tibble()%>%
  mutate_at(c("Deaths"),scale)
z<-0.4417*res$"Confirmed"+0.2388*res$"Death_Rate"+0.1632*res$"R0_min"+0.0981*res$"Deaths"
ggplot()+
  geom_point(aes(x=c(1:11),y=z))

# can't converse the data, just plot
fac<-c(1:6)
rate<-c(0.4417,0.6806,0.8437,0.9356,0.9842,1)
ggplot()+
  geom_line(aes(x=fac,y=rate))+
  labs(x="Index",y="Cumulative Contribution Rate")

dis<-c(1:11)
grade<-c(20,50,70,80,62,75,65,80,88,97,92)
ggplot()+
  geom_point(aes(x=dis,y=grade))+
  geom_abline(intercept=30,slope=0)+
  geom_abline(intercept=60,slope=0)+
  geom_abline(intercept=90,slope=0)+
  labs(x="Disease",y="Score")

#--------------------------------------------------------------------------
#     3.5 First improvement SEIR-CHONGQING
#--------------------------------------------------------------------------

# ! Don't run normalizate(). If not sure, re-run lines 12-78
data_cq<-data_glb%>%
  filter(Province.State=="Chongqing")
N <- data_cq$Population[1]/29           # Susceptible
num_peo<-tibble(
  E=c(1),                               # Asymptomatic
  I=c(6),                               # Infected
  S=c(N-I),                             # Healthy
  R=c(0),                               # Rehabilitee
  D=c(as.Date("2020-01-22"))            # Date
)


a <- 0.1          # probability  Asymptomatic->infected
r <- 7            # Number infected exposed susceptible
r2 <- 20          # Number potential contacts susceptible
B <- 0.03         # Transmission probability
B2 <- 0.03        # probability Asymptomatic ->health
y <- 0.98         # The probability of recovery

T <- 1:200        # Date
for(i in T){
  if(i>25){       # 1.24 issued 1-level and +14
    r=5
    r2=5
  }
  DD = as.Date(num_peo[[i,5]]+1)
  SS = num_peo[[i,3]] - r*B*num_peo[[i,3]]*num_peo[[i,2]]/N - r2*B2*num_peo[[i,3]]*num_peo[[i,1]]/N
  EE = num_peo[[i,1]] + r*B*num_peo[[i,3]]*num_peo[[i,2]]/N-a*num_peo[[i,1]] + r2*B2*num_peo[[i,3]]*num_peo[[i,1]]/N
  II = num_peo[[i,2]] + a*num_peo[[i,1]] - y*num_peo[[i,2]]
  RR = num_peo[[i,4]] + y*num_peo[[i,2]]
  num_peo<-add_row(num_peo,E=EE,I=II,S=SS,R=RR,D=DD)
}

# Drawing gap is large
ggplot(data=num_peo)+
  geom_line(mapping=aes(x=D,y=S,color="Susceptible"))+
  geom_line(mapping=aes(x=D,y=E,color="Asymptomatic"))+
  geom_line(mapping=aes(x=D,y=I,color="Infected"))+
  geom_line(mapping=aes(x=D,y=R,color="Recovery"))+
  geom_line(data=data_cq,mapping=aes(x=Date,y=Confirmed-Deaths-Recovered,color="Real_confirmed"))+
  geom_point(data=data_cq,mapping=aes(x=Date,y=Recovered+Deaths,color="Real_recovery"))+
  geom_vline(xintercept = as.Date("2020-01-22")+17)+
  geom_text(aes(x=as.Date("2020-01-22")+17,y=3e5,label="Prevention &\n control measures \ntake effect"))+
  labs(x="Date",y="Population")


#--------------------------------------------------------------------------
#     3.6 Second improvement SEIR-HUBEI
#--------------------------------------------------------------------------
data_hb<-data_glb%>%
  filter(Province.State=="Hubei")

N<-59170000               # Total population of Hubei
num_peo2<-tibble(
  S=c(59170000),          # Total population of Hubei
  E=c(4007),              # New confirmed cases 1.23-1.29
  I=c(786),               # Infected
  Sq=c(2776),             # Under medical observation
  Eq=c(400),              # Estimate, sleeper being quarantined
  H=c(1186),              # Patient in the hospital,=I+Eq
  R=c(31),                # Discharged patients 
  D=c(as.Date("2020-01-22"))   # Date
)

# Model parameter setting
cr<-2                         # Contact rate
deltaI<-0.13                  # Isolation speed of infected
deltaq<-0.13                  # Rate 'Eq'->'I'
gammaI<-0.007                 # Recovery rate of infected
gammaH<-0.014                 # Speed of 'Eq'
beta<-2.05*10^(-9)            # Probability of infection
q<-1*10^(-6)                  # Isolation ratio
alpha<-2.7*10^(-4)            # Fatality rate
rho<-1                        # Effective contact coefficient
theta1<-1                     # Spread nanni H/I
lambda<-1/14                  # Isolation contact speed 1/14
sigma<-1/7                    # Speed Asymptomatic to infected 1/7
# Difference iterative equation
T=1:200;
for(i in T){
  if(i>30){
    gammaI<-(0.025*(i-30))
    theta1<-0.55
  }
  if(i>65){
    gammaI<-0.98
  }
  # Susceptible number iteration
  SN=num_peo2[[i,1]]-(rho*cr*beta+rho*cr*q*(1-beta))*num_peo2[[i,1]]*(num_peo2[[i,3]]+theta1*num_peo2[[i,2]])+lambda*num_peo2[[i,4]]
  # Number of lurkers iteration
  EN=num_peo2[[i,2]]+rho*cr*beta*(1-q)*num_peo2[[i,1]]*(num_peo2[[i,3]]+theta1*num_peo2[[i,2]])-sigma*num_peo2[[i,2]]
  # Iterative number of infected people
  IN=num_peo2[[i,3]]+sigma*num_peo2[[i,2]]-(deltaI+alpha+gammaI)*num_peo2[[i,3]]
  # Isolate the susceptible number of iterations
  SqN=num_peo2[[i,4]]+rho*cr*q*(1-beta)*num_peo2[[i,1]]*(num_peo2[[i,3]]+theta1*num_peo2[[i,2]])-lambda*num_peo2[[i,4]]
  # Isolate the number of lurking iterations
  EqN=num_peo2[[i,5]]+rho*cr*beta*q*num_peo2[[i,1]]*(num_peo2[[i,3]]+theta1*num_peo2[[i,2]])-deltaq*num_peo2[[i,5]]
  # Iteration of inpatients
  HN=num_peo2[[i,6]]+deltaI*num_peo2[[i,3]]+deltaq+num_peo2[[i,5]]-(alpha+gammaH)*num_peo2[[i,6]]
  # Iterative number of rehabilitation
  RN=num_peo2[[i,7]]+gammaI*num_peo2[[i,3]]+gammaH*num_peo2[[i,6]]
  DN=as.Date(num_peo2[[i,8]]+1)
  num_peo2<-add_row(num_peo2,S=SN,E=EN,I=IN,Sq=SqN,Eq=EqN,H=HN,R=RN,D=DN)
}

ggplot(data=num_peo2,size=8)+
  geom_line(data=data_hb,mapping=aes(x=Date,y=Confirmed-Deaths-Recovered,color="Real_confirmed "))+
  geom_line(mapping=aes(x=D,y=E,color="Asymptomatic"))+
  geom_line(mapping=aes(x=D,y=I,color="Infected"))+
  scale_x_date(date_breaks = "1 month", date_minor_breaks = "1 month", date_labels = "%b")+
  geom_vline(xintercept = as.Date("2020-02-21")+17)+
  geom_text(aes(x=as.Date("2020-02-21")+17,y=50000,label=" Wu Han\nCle ar "))+
  labs(x="Date",y="Population")
  
    
ggplot(data=num_peo2,size=4)+
  geom_line(mapping=aes(x=D,y=Sq,color="Susceptible"))+
  geom_vline(xintercept = as.Date("2020-02-21")+17)+
  geom_text(aes(x=as.Date("2020-02-21")+17,y=10000000,label=" Wu Han\nCle ar "))+
  labs(x="Date",y="Population")

ggplot(data=num_peo2,size=4)+
  geom_line(mapping=aes(x=D,y=R,color="Recovery"))+
  geom_vline(xintercept = as.Date("2020-02-21")+17)+
  geom_text(aes(x=as.Date("2020-02-21")+17,y=200000,label=" Wu Han\nCle ar "))+
  labs(x="Date",y="Population")
