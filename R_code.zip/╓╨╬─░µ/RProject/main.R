library(tidyverse)
library(purrr)
library(psych)

#--------------------------------------------------------------------------
#     3.3 数据预处理
#--------------------------------------------------------------------------

# 若使用Rpeoject打开则无需手动设置工作路径
# setwd("C:/Users/tclkr/Desktop/COVID19")

data_state_local<-read.csv("../data/reference.csv")
data_state_number<-read.csv("../data/time-series-19-covid-combined.csv")
data_us_confirmed<-read.csv("../data/us_confirmed.csv")
data_us_die<-read.csv("../data/us_deaths.csv")
data_world_summary<-read.csv("../data/worldwide-aggregated.csv")

get_key<-function(a,b){
  if(a==''){
    # 遇到一个bug，但是这样复杂一点就能运行
    return(paste(b))
  }
  return(paste(a,sep =" ,",b))
}

## 数据清洗
### 世界各国(省)数据
data_state_local$Combined_Key=as.character(data_state_local$Combined_Key)
data_glb<-data_state_number%>%
  # num的经纬度精度不如local的好
  select(-Long,-Lat)%>%
  mutate(Combined_Key = purrr::map2_chr(Province.State,Country.Region,get_key))

# 清洗主键
data_state_local$Combined_Key<-gsub(" , ",",",data_state_local$Combined_Key)
data_state_local$Combined_Key<-gsub(", ",",",data_state_local$Combined_Key)
data_state_local$Combined_Key<-gsub(" ,",",",data_state_local$Combined_Key)
data_glb$Combined_Key<-gsub(" , ",",",data_glb$Combined_Key)
data_glb$Combined_Key<-gsub(", ",",",data_glb$Combined_Key)
data_glb$Combined_Key<-gsub(" ,",",",data_glb$Combined_Key)

data_glb<-data_glb%>%
  left_join(select(data_state_local,-c(UID:Country_Region)),by="Combined_Key")

# 如果用如下方式合并可能经纬度只有68%完整度
data_state_local$Country_Region<-as.character(data_state_local$Country_Region)
data_state_number$Country.Region<-as.character(data_state_number$Country.Region)
data_state_local$Province_State<-as.character(data_state_local$Province_State)
data_state_number$Province.State<-as.character(data_state_number$Province.State)
data_glb<-data_state_number%>%
  # num的经纬度精度不如local的好
  select(-Long,-Lat)%>%
  left_join(select(data_state_local,-c(UID:Country_Region)),by=c("Country.Region","Provience.State"))

### 美国数据
data_us_confirmed$Combined_Key=as.character(data_us_confirmed$Combined_Key)
data_us_confirmed<-data_us_confirmed%>%
  select(Combined_Key,Date,Case)
data_us_die$Combined_Key=as.character(data_us_die$Combined_Key)
data_us_die<-data_us_die%>%
  select(-c(UID:Admin2))
data_us<-data_us_confirmed%>%
  left_join(data_us_die,by=c("Combined_Key","Date"))%>%
  mutate(confirmed=Case.x,die=Case.y)%>%
  select(-Case.x,-Case.y,-Country.Region)

### 释放无用数据空间
rm(data_state_local,data_state_number,data_us_confirmed,data_us_die)

### dataframe转tribble，识别时间格式
data_us<-as_tibble(data_us)
data_glb<-as_tibble(data_glb)%>%
  filter(is.na(Recovered)==FALSE,is.na(Confirmed)==FALSE,is.na(Deaths)==FALSE,
         is.na(Long_)==FALSE,is.na(Lat)==FALSE,is.na(Population)==FALSE)
data_world_summary<-as_tibble(data_world_summary)
data_world_summary$Date<-as.Date(data_world_summary$Date)
data_us$Date<-as.Date(data_us$Date)
data_glb$Date<-as.Date(data_glb$Date)

# 预览时间人口关系
ggplot()+
  geom_point(data=data_world_summary,mapping=aes(x=Date,y=Confirmed-Recovered))+
  theme(axis.text.x = element_text(angle = 45, hjust = 1.3))+
  scale_x_date(date_breaks = "1 week", date_minor_breaks = "1 week", date_labels = "%b%d")+
  labs(x="日期",y="人数")

## 计算数据完整度
# 想看则不要执行72-74行否则数据洗好了全是100%
for(i in seq_along(data_glb)){
  print(100-100*sum(as.vector(is.na(data_glb[,i])))/as.integer(count(data_glb[,i])))
}
# 释放临时变量空间
rm(i)

## 计算皮尔逊相关系数
get_per_cor<-function(x,y){
  x<-as.integer(x)
  y<-as.integer(y)
  n<-length(y)
  mean_x<-mean(x)
  mean_y<-mean(y)
  sd_x<-sd(x)
  sd_y<-sd(y)
  print(sd_x)
  cov_xy<-sum((x-mean_x)*(y-mean_y))/(n-1)
  return(cov_xy/sd_x/sd_y)
}

# 不能用for写只能手写
get_per_cor(as.integer(data_world_summary$Date-as.Date("2020-01-21")),as.integer(data_world_summary$Date-as.Date("2020-01-21")))
get_per_cor(as.integer(data_world_summary$Date-as.Date("2020-01-21")),data_world_summary$Recovered)
get_per_cor(as.integer(data_world_summary$Date-as.Date("2020-01-21")),data_world_summary$Confirmed)
get_per_cor(as.integer(data_world_summary$Date-as.Date("2020-01-21")),data_world_summary$Deaths)

get_per_cor(data_world_summary$Recovered,as.integer(data_world_summary$Date-as.Date("2020-01-21")))
get_per_cor(data_world_summary$Recovered,data_world_summary$Recovered)
get_per_cor(data_world_summary$Recovered,data_world_summary$Confirmed)
get_per_cor(data_world_summary$Recovered,data_world_summary$Deaths)

get_per_cor(data_world_summary$Confirmed,as.integer(data_world_summary$Date-as.Date("2020-01-21")))
get_per_cor(data_world_summary$Confirmed,data_world_summary$Recovered)
get_per_cor(data_world_summary$Confirmed,data_world_summary$Confirmed)
get_per_cor(data_world_summary$Confirmed,data_world_summary$Deaths)

get_per_cor(data_world_summary$Deaths,as.integer(data_world_summary$Date-as.Date("2020-01-21")))
get_per_cor(data_world_summary$Deaths,data_world_summary$Recovered)
get_per_cor(data_world_summary$Deaths,data_world_summary$Confirmed)
get_per_cor(data_world_summary$Deaths,data_world_summary$Deaths)

data_world_summary2<-data_world_summary[-1,]
get_per_cor(data_world_summary2$Increase.rate,as.integer(data_world_summary2$Date-as.Date("2020-01-21")))
get_per_cor(data_world_summary2$Increase.rate,data_world_summary2$Recovered)
get_per_cor(data_world_summary2$Increase.rate,data_world_summary2$Confirmed)
get_per_cor(data_world_summary2$Increase.rate,data_world_summary2$Deaths)
get_per_cor(data_world_summary2$Increase.rate,data_world_summary2$Increase.rate)
get_per_cor(data_world_summary2$Deaths,data_world_summary2$Increase.rate)
get_per_cor(data_world_summary2$Recovered,data_world_summary2$Increase.rate)
get_per_cor(data_world_summary2$Confirmed,data_world_summary2$Increase.rate)
get_per_cor(as.integer(data_world_summary2$Date-as.Date("2020-01-21")),data_world_summary2[,-1]$Increase.rate)
rm(data_world_summary2)

# 无法直接转化只能手抄
cor_res<-tribble(
  ~Var1,              ~Var2,           ~Value,
  "日期",             "日期",          1,
  "日期",             "感染数",        0.8065011,
  "日期",             "治愈数",        0.8404169,
  "日期",             "死亡数",        0.7655985,
  "日期",             "增长率",        -0.4506009,
  "感染数",           "日期",          0.8065011,
  "感染数",           "感染数",        1,
  "感染数",           "治愈数",        0.9893401,
  "感染数",           "死亡数",        0.9953976,
  "感染数",           "增长率",        -0.2113539,
  "治愈数",           "日期",          0.8404169,
  "治愈数",           "感染数",        0.8065011,
  "治愈数",           "治愈数",        1,
  "治愈数",           "死亡数",        0.9887518,
  "治愈数",           "增长率",        -0.2457062,
  "死亡数",           "日期",          0.7655985,
  "死亡数",           "感染数",        0.9953976,
  "死亡数",           "治愈数",        0.9887518,
  "死亡数",           "死亡数",        1,
  "死亡数",           "增长率",        -0.1953711,
  "增长率",           "日期",          -0.4506009,
  "增长率",           "感染数",        -0.2113539,
  "增长率",           "治愈数",        -0.2457062,
  "增长率",           "死亡数",        -0.1953711,
  "增长率",           "增长率",        1
)

# 相关系数热图
ggplot(data = cor_res, aes(x=Var2, y=Var1, fill = Value)) +
  geom_tile(color = "white") +
  scale_fill_gradient2(low = "blue", high = "red", mid = "white",
                       midpoint = 0, limit = c(-1, 1), space = "Lab",
                       name="相关系数") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                   size = 12, hjust = 1)) +
  coord_fixed() + 
  geom_text(aes(Var2, Var1, label = Value), color = "black", size = 3)+
  labs(x="变量1",y="变量2")
# 删除临时变量
rm(cor_res)

## 数据归一化
normalizate<-function(data){
  dmax<-max(data)
  dmin<-min(data)
  return((data-dmin)/(dmax-dmin))
}

# 归一化
data_glb$Confirmed<-normalizate(data_glb$Confirmed)
data_glb$Recovered<-normalizate(data_glb$Recovered)
data_glb$Deaths<-normalizate(data_glb$Deaths)

data_us$confirmed<-normalizate(data_us$confirmed)
data_us$die<-normalizate(data_us$die)

data_world_summary$Confirmed<-normalizate(data_world_summary$Confirmed)
data_world_summary$Recovered<-normalizate(data_world_summary$Recovered)
data_world_summary$Deaths<-normalizate(data_world_summary$Deaths)

# R聚类
# 添加数据
data_R_cluste<-tribble(
    ~Disease_Name,    ~Confirmed,    ~Deaths,     ~Recovered,       ~Death_Rate,   ~R0_min,	      ~R0_max,    ~incubation,    ~Rate_asymptomatic,     ~Date,      ~Country_Rate,    ~Origin_City_Population,    ~GDP,    ~Density_People,     ~Act_Gov,
    "Hepatitis B",  	300000000,    	17000,    	2999998300,	      0.000005,      1,            	2,        	70,           	0,                    	8030,      	1,              	15305900,                 	21874,  	2059,             	NA,
    "Black Death",  	85000000,     	78700000,  	6300000,        	0.9258,        1,	            3,	        3, 	            0.12,                  	2555,     	1,              	70000000,                 	31058,   	16,               	0,
    "cholera",     	  461783,       	8072,      	453711,          	0.0068,        1,           	2,        	2,            	0.07,                  	1277,      	1,              	7510100,                  	3894,     554,              	NA,
    "measles",      	250270,       	5110,     	245160,          	0.0020,        12,          	18,       	10,           	0.08,                 	317,      	0.025,          	1800000,                  	3198,     1772,              	NA,
    "diphtheria",   	2839,          	67,        	2772,           	0.0235,        6,	            7,	        3,	            0.11,	                  115,	      0.01,	            257740000,                  3894,   	554,               	NA,
    "smallpox",     	6000,          	850,        5150,            	0.3,           5,           	7,	        14,	            0,	                    730,	      1,	              11000,                    	46170,   	963,               	NA,
    "polio",      	  NA,            	NA,	        NA,              	NA,            5,	            7,	        11,	            0,	                    NA,	        1,	              NA,	                        NA,     	NA,               	NA, 
    "rubella",    	  NA,           	NA,	        NA,             	0.0013,        5,	            7,	        11,	            0.01,                   NA,	        NA,	              NA,	                        NA,     	NA,               	NA,
    "Mumps",      	  NA,            	NA,	        NA,             	0.0002,     	 5,           	7,	        19,	            0.06,                   NA,	        NA,	              NA,	                        NA,     	NA,               	NA, 
    "HIV/AIDS",   	  NA,           	NA,	        NA,             	NA,         	 2,	            5,	        11,	            0.04,                   NA,	        1,	              NA,	                        NA,     	NA,               	NA,
    "pertussis",  	  75598200,     	5292,      	75592908,       	0.00007,     	 4,   	        7,	        13,	            0.09,                   183,        1,	              8900000,                    46500,  	4761,             	NA,
    "SARS",       	  8422,          	919,       	7503,           	0.17,          0.85,        	3,	        7,	            0.11,                   270,        0.162,	          7251900,	                  7404,     975,              	NA,
    "MERS",       	  1139,         	431,       	708,            	0.37,       	 1,	            2,	        5.2,	          0.18,                   218,        0.061,	          436000,                     25059,		965,                NA,
    "HIN1",       	  25449514,     	19449,     	25430065,       	0.012,       	 1.75,	        1.75,	      4,	            0.19,                   485,        1,	              38310000,                 	49911,   	90,                	NA,
    "COVID-19",   	  7221717,      	411818,	    6809899,         	0.05,        	 3.77,	        3.77,	      14, 	          0.17,                   190,        1,	              12212000,                  	21098,   	2334,              	1
)

# 求相关系数
data_R_cluste<-data_R_cluste%>%
  filter(is.na(Confirmed)==FALSE)%>%
  select(-Act_Gov)
x_star<-scale(as.data.frame(select(data_R_cluste,-Disease_Name)))
hc<-hclust(dist(x_star),method = "ave")
plot(hc,hang=-1)
# 求标准化的相关系数
sc<-as.data.frame(select(data_R_cluste,-Disease_Name))
center <- sweep(sc, 2, apply(sc, 2, min),'-')  
R <- apply(sc, 2, max) - apply(sc,2,min)       
x_star<- sweep(center, 2, R, "/")             
hc<-hclust(dist(x_star),method = "ave")
plot(hc,hang=-1)
# 移除临时变量
rm(hc,sc,x_star,center)

# Q聚类
data_R_cluste<-select(data_R_cluste,-Disease_Name)
sc<-t(sc)
x_star<-t(x_star)
sc<-dist(data_R_cluste,"minkowski")
hc<-hclust(dist(sc),method = "ave")
plot(hc,hang=-1)

# 主成分分析法
d<-data_R_cluste
sd=scale(d)
sd
pca=princomp(d,cor=T) 
screeplot(pca,type="line",lwd=2) 
dcor=cor(d)
deig=eigen(dcor)
deig$values
sumeigv=sum(deig$values)
sumeigv
sum(deig$values[1:2])/k
pca$loadings[,1:2]
deigvalues[1]/k
deigvalues[2]/k
C=(b1*C1+b2*C2)/(b1+b2)=q1*C1+q2*C2
s=pca$scores[,1:2] 
cbind(s,c)

# 转不了数据直接抄下四个参数
res<-scale(as.data.frame(select(data_R_cluste,-Disease_Name)))%>%
  as_tibble()%>%
  mutate_at(c("Deaths"),scale)
z<-0.4417*res$"Confirmed"+0.2388*res$"Death_Rate"+0.1632*res$"R0_min"+0.0981*res$"Deaths"
ggplot()+
  geom_point(aes(x=c(1:11),y=z))

# 转不了数据直接画图
fac<-c(1:6)
rate<-c(0.4417,0.6806,0.8437,0.9356,0.9842,1)
ggplot()+
  geom_line(aes(x=fac,y=rate))+
  labs(x="指标",y="累计贡献率")

dis<-c(1:11)
grade<-c(20,50,70,80,62,75,65,80,88,97,92)
ggplot()+
  geom_point(aes(x=dis,y=grade))+
  geom_abline(intercept=30,slope=0)+
  geom_abline(intercept=60,slope=0)+
  geom_abline(intercept=90,slope=0)+
  labs(x="疾病",y="得分")

#--------------------------------------------------------------------------
#     3.5 第一次改进SEIR-重庆
#--------------------------------------------------------------------------

# ! 不要运行标准化函数,不确定就重新执行12-78行
data_cq<-data_glb%>%
  filter(Province.State=="Chongqing")
N <- data_cq$Population[1]/29           # 易感者
num_peo<-tibble(
  E=c(1),                               # 无症状感染者
  I=c(6),                               # 感染者
  S=c(N-I),                             # 健康者
  R=c(0),                               # 康复者
  D=c(as.Date("2020-01-22"))            # 日期
)

# 设置参数
a <- 0.1                     # 潜伏者转化为感染者概率
r <- 7                       # 感染者接触易感者的人数
r2 <- 20                     # 潜伏者接触易感者的人数
B <- 0.03                    # 传染概率
B2 <- 0.03                   # 潜伏者传染正常人的概率
y <- 0.98                    # 康复概率

T <- 1:200                   # 时间
for(i in T){
  if(i>25){         # 重庆市1.24发布为一级响应再加14天
    r=5             # 积极防疫措施
    r2=5
  }                 # 迭代方程
  DD = as.Date(num_peo[[i,5]]+1)
  SS = num_peo[[i,3]] - r*B*num_peo[[i,3]]*num_peo[[i,2]]/N - r2*B2*num_peo[[i,3]]*num_peo[[i,1]]/N
  EE = num_peo[[i,1]] + r*B*num_peo[[i,3]]*num_peo[[i,2]]/N-a*num_peo[[i,1]] + r2*B2*num_peo[[i,3]]*num_peo[[i,1]]/N
  II = num_peo[[i,2]] + a*num_peo[[i,1]] - y*num_peo[[i,2]]
  RR = num_peo[[i,4]] + y*num_peo[[i,2]]
  num_peo<-add_row(num_peo,E=EE,I=II,S=SS,R=RR,D=DD)
}

# 绘图差距较大
ggplot(data=num_peo)+
  geom_line(mapping=aes(x=D,y=S,color="易感者"))+
  geom_line(mapping=aes(x=D,y=E,color="无症状感染者"))+
  geom_line(mapping=aes(x=D,y=I,color="感染者"))+
  geom_line(mapping=aes(x=D,y=R,color="康复者"))+
  geom_line(data=data_cq,mapping=aes(x=Date,y=Confirmed-Deaths-Recovered,color="实际确诊"))+
  geom_point(data=data_cq,mapping=aes(x=Date,y=Recovered+Deaths,color="实际痊愈"))+
  geom_vline(xintercept = as.Date("2020-01-22")+17)+
  geom_text(aes(x=as.Date("2020-01-22")+17,y=3e5,label="防 控\n措 施\n生 效"))+
  labs(x="时间",y="人数")


#--------------------------------------------------------------------------
#     3.6 第二次改进SEIR-湖北
#--------------------------------------------------------------------------
data_hb<-data_glb%>%
  filter(Province.State=="Hubei")

N<-59170000                          # 湖北省人口总数
num_peo2<-tibble(
  S=c(59170000),                     # 湖北省人口总数
  E=c(4007),                         # 1月23至1月29日新增确诊病例数
  I=c(786),                          # 感染者
  Sq=c(2776),                        # 尚在接受医学观察的人数
  Eq=c(400),                         # 估计值，为正在被隔离的潜伏者
  H=c(1186),                         # 正在住院的患者，为感染者和被隔离的潜伏者之和
  R=c(31),                           # 官方公布的出院人数
  D=c(as.Date("2020-01-22"))         # 日期
)

# 模型参数设定
cr<-2                               # 接触率
deltaI<-0.13                        # 感染者的隔离速度
deltaq<-0.13                        # 隔离潜伏者向隔离感染者的转化速率
gammaI<-0.007                       # 感染者的恢复率
gammaH<-0.014                       # 隔离感染者的恢复速率
beta<-2.05*10^(-9)                  # 传染概率
q<-1*10^(-6)                        # 隔离比例
alpha<-2.7*10^(-4)                  # 病死率
rho<-1                              # 有效接触系数，参考取1
theta1<-1                           # 潜伏者相对于感染者的传染能力比值
lambda<-1/14                        # 隔离接触速度，为14天的倒数
sigma<-1/7                          # 潜伏者向感染者的转化速度，平均潜伏期为7天，为7天的倒数
# 差分迭代方程
T=1:200;
for(i in T){
  if(i>30){
    gammaI<-(0.025*(i-30))
    theta1<-0.55
  }
  if(i>65){
    gammaI<-0.98
  }
  # 易感人数迭代
  SN=num_peo2[[i,1]]-(rho*cr*beta+rho*cr*q*(1-beta))*num_peo2[[i,1]]*(num_peo2[[i,3]]+theta1*num_peo2[[i,2]])+lambda*num_peo2[[i,4]]
  # 潜伏者人数迭代
  EN=num_peo2[[i,2]]+rho*cr*beta*(1-q)*num_peo2[[i,1]]*(num_peo2[[i,3]]+theta1*num_peo2[[i,2]])-sigma*num_peo2[[i,2]]
  # 感染者人数迭代
  IN=num_peo2[[i,3]]+sigma*num_peo2[[i,2]]-(deltaI+alpha+gammaI)*num_peo2[[i,3]]
  # 隔离易感染着人数迭代
  SqN=num_peo2[[i,4]]+rho*cr*q*(1-beta)*num_peo2[[i,1]]*(num_peo2[[i,3]]+theta1*num_peo2[[i,2]])-lambda*num_peo2[[i,4]]
  # 隔离潜伏者人数迭代
  EqN=num_peo2[[i,5]]+rho*cr*beta*q*num_peo2[[i,1]]*(num_peo2[[i,3]]+theta1*num_peo2[[i,2]])-deltaq*num_peo2[[i,5]]
  # 住院患者人数迭代
  HN=num_peo2[[i,6]]+deltaI*num_peo2[[i,3]]+deltaq+num_peo2[[i,5]]-(alpha+gammaH)*num_peo2[[i,6]]
  # 康复人数迭代 
  RN=num_peo2[[i,7]]+gammaI*num_peo2[[i,3]]+gammaH*num_peo2[[i,6]]
  DN=as.Date(num_peo2[[i,8]]+1)
  num_peo2<-add_row(num_peo2,S=SN,E=EN,I=IN,Sq=SqN,Eq=EqN,H=HN,R=RN,D=DN)
}

ggplot(data=num_peo2,size=8)+
  geom_line(data=data_hb,mapping=aes(x=Date,y=Confirmed-Deaths-Recovered,color="实际确诊"))+
  geom_line(mapping=aes(x=D,y=E,color="无症状感染者"))+
  geom_line(mapping=aes(x=D,y=I,color="感染者"))+
  scale_x_date(date_breaks = "1 month", date_minor_breaks = "1 month", date_labels = "%b")+
  geom_vline(xintercept = as.Date("2020-02-21")+17)+
  geom_text(aes(x=as.Date("2020-02-21")+17,y=50000,label="武 汉\n清 零"))+
  labs(x="时间",y="人数")
  
    
ggplot(data=num_peo2,size=4)+
  geom_line(mapping=aes(x=D,y=Sq,color="易感者"))+
  geom_vline(xintercept = as.Date("2020-02-21")+17)+
  geom_text(aes(x=as.Date("2020-02-21")+17,y=50000,label="武 汉\n清 零"))+
  labs(x="时间",y="人数")

ggplot(data=num_peo2,size=4)+
  geom_line(mapping=aes(x=D,y=R,color="康复者"))+
  geom_vline(xintercept = as.Date("2020-02-21")+17)+
  geom_text(aes(x=as.Date("2020-02-21")+17,y=200000,label="武 汉\n清 零"))+
  labs(x="时间",y="人数")

